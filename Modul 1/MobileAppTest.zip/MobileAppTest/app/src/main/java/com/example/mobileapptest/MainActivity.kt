package com.example.mobileapptest

import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mobileapptest.ui.theme.MobileAppTestTheme
import androidx.compose.foundation.Image as Image2

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MobileAppTestTheme {
                DiceRollerApp()

            }
        }
    }
}

@Preview
@Composable
fun DiceRollerApp() {
    DiceButtonWithImage()
}


@Composable
fun DiceButtonWithImage(modifier: Modifier = Modifier .fillMaxSize() .wrapContentSize(Alignment.Center)) {
    var result1 by remember{mutableStateOf( 0)}
    var result2 by remember{mutableStateOf( 0)}
    val context = LocalContext.current

    val result1Image = getImage(result1)
    val result2Image = getImage(result2)

    Column (
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier){
            Image2(
                painter = painterResource(id = result1Image),
                contentDescription = result1.toString(),
                modifier = Modifier.padding(8.dp)
            )
            Image2(
                painter = painterResource(id = result2Image),
                contentDescription = result2.toString(),
                modifier = Modifier.padding(8.dp)

            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            result1 = (1..6).random()
            result2 = (1..6).random()
        if(result1 == result2){
            Toast.makeText(context, "Selamat anda dapat dadu double!", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(context, "Anda belum beruntung", Toast.LENGTH_SHORT).show()
        }
        }) {
            Text(stringResource(R.string.roll))
        }
    }

}

@Composable
fun getImage(diceValue: Int): Int {
    return when (diceValue){
        1 -> R.drawable.dice_1
        2 -> R.drawable.dice_2
        3 -> R.drawable.dice_3
        4 -> R.drawable.dice_4
        5 -> R.drawable.dice_5
        6 -> R.drawable.dice_6
        else -> R.drawable.dice_0
    }
}
